
/!\

This model is for MG5aMC parallel tests only and cannot be trusted.
It has NOT be validated and some results WILL be wrong.

/!\
